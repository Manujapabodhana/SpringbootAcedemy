package com.spring.point_of_scale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointOfScaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
