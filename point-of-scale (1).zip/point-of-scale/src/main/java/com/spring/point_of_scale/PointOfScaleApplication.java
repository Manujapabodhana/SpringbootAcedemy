package com.spring.point_of_scale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PointOfScaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PointOfScaleApplication.class, args);
	}

}
